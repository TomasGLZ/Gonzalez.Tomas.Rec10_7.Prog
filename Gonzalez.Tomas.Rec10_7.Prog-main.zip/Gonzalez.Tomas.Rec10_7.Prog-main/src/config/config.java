package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public class config {
    public static final Path PATH_CSV = Paths.get("src/resources/torneos.csv");
    public static final Path PATH_SER = Paths.get("src/resources/torneos.dat");
}
