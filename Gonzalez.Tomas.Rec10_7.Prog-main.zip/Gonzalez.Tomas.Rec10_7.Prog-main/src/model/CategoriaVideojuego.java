
package model;


public enum CategoriaVideojuego {
    ONLINE, PRESENCIAL
}
